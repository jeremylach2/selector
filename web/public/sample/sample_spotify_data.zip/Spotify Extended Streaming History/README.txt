Synthetic sample export for the Selector demo. The listener is invented: tracks are real catalog entries, but every timestamp, skip and play count was generated.
